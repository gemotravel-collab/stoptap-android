# StopTap v5 alpha — native Android widget bridge

This project is the first step from the Netlify field-test into a real Android home-screen widget.

## What works in this alpha source

- The Android app opens the existing StopTap control centre in a WebView.
- Android location permission is handled natively and passed through to the web control centre.
- `web_v43/index.html` calls the Android bridge when **CREATE WIDGET ROUTE** is pressed.
- The app saves that route and calls Android's `requestPinAppWidget()` API.
- On compatible launchers, Android should show the system prompt asking where to place the StopTap widget.
- The widget displays the saved route name and selected FROM/TO stops.
- Tapping the FROM/TO stop opens the official Adelaide Metro live stop page as an interim fallback.
- Tapping REFRESH redraws the widget and updates its timestamp.

## Important limitation of this alpha

The widget does **not yet parse Adelaide Metro GTFS-Realtime arrivals**. It is an actual Android widget shell and route bridge, not yet the final 30-minute live-arrivals widget. The next build should add the real-time trip update layer and show every relevant bus arriving within the configured 30-minute window.

## Before building

1. Redeploy the contents of `web_v43/` to the same Netlify project used for the v4.2 field test. Keeping the same Netlify site URL means the default Android source does not need to change.
2. If the Netlify URL changes, edit `app/src/main/res/values/strings.xml` and update `control_centre_url`.
3. Open the root folder in Android Studio and build/install the app.

## Test flow

1. Open StopTap Android alpha.
2. Create a route exactly as in v4.2.
3. Press **CREATE WIDGET ROUTE**.
4. Android should show its native widget pin confirmation (on launchers supporting direct pinning).
5. Accept it and place the widget.
6. Tap FROM or TO on the widget to open the official live stop page.

## Next milestone

Replace the interim live links with GTFS-Realtime trip updates, filter to the saved stops and routes, and show only services due within the next 30 minutes.
