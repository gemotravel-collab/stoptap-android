package au.com.stoptap.app;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class WidgetPinnedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;
        String route = context.getSharedPreferences("stoptap", Context.MODE_PRIVATE)
                .getString("pending_route", null);
        if (route != null) {
            context.getSharedPreferences("stoptap", Context.MODE_PRIVATE).edit()
                    .putString("widget_route_" + widgetId, route)
                    .apply();
        }
        StopTapWidget.updateOne(context, AppWidgetManager.getInstance(context), widgetId);
    }
}
