package au.com.stoptap.app;

import android.Manifest;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;

import android.app.Activity;

public class MainActivity extends Activity {
    private static final int LOCATION_REQ = 1001;
    private WebView webView;
    private String pendingOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportMultipleWindows(false);

        webView.addJavascriptInterface(new NativeBridge(), "StopTapAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost();
                if (host.endsWith("netlify.app")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; }
                catch (Exception e) { return false; }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQ);
                }
            }
        });

        webView.loadUrl(getString(R.string.control_centre_url));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQ && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingOrigin, granted, false);
            pendingGeoCallback = null;
            pendingOrigin = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void pinWidget() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, StopTapWidget.class);
        if (manager.isRequestPinAppWidgetSupported()) {
            Intent callbackIntent = new Intent(this, WidgetPinnedReceiver.class);
            PendingIntent callback = PendingIntent.getBroadcast(
                    this, 0, callbackIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            boolean requested = manager.requestPinAppWidget(provider, null, callback);
            if (!requested) Toast.makeText(this, "Your launcher did not accept the widget request.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Long-press your home screen → Widgets → StopTap.", Toast.LENGTH_LONG).show();
        }
    }

    private class NativeBridge {
        @JavascriptInterface
        public void saveRoute(String json) {
            getSharedPreferences("stoptap", MODE_PRIVATE).edit()
                    .putString("latest_route", json)
                    .putString("pending_route", json)
                    .apply();
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "Route saved. Choose where to place the StopTap widget.", Toast.LENGTH_LONG).show();
                pinWidget();
            });
        }
    }
}
