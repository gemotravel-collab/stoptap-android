package au.com.stoptap.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StopTapWidget extends AppWidgetProvider {
    public static final String ACTION_REFRESH = "au.com.stoptap.app.REFRESH_WIDGET";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) updateOne(context, AppWidgetManager.getInstance(context), id);
        }
    }

    static void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        String json = context.getSharedPreferences("stoptap", Context.MODE_PRIVATE)
                .getString("widget_route_" + widgetId, null);
        if (json == null) json = context.getSharedPreferences("stoptap", Context.MODE_PRIVATE)
                .getString("latest_route", null);

        String routeName = "StopTap route";
        String fromText = "Create a route in StopTap";
        String toText = "Then add this widget again";
        String fromCode = null;
        String toCode = null;

        if (json != null) {
            try {
                JSONObject route = new JSONObject(json);
                routeName = route.optString("name", routeName);
                JSONArray from = route.optJSONArray("from");
                JSONArray to = route.optJSONArray("to");
                if (from != null && from.length() > 0) {
                    JSONObject s = from.getJSONObject(0);
                    fromCode = s.optString("code", "");
                    fromText = "FROM · " + s.optString("name", "Stop") + (fromCode.isEmpty() ? "" : " · #" + fromCode);
                    if (from.length() > 1) fromText += "  +1 stop";
                }
                if (to != null && to.length() > 0) {
                    JSONObject s = to.getJSONObject(0);
                    toCode = s.optString("code", "");
                    toText = "TO · " + s.optString("name", "Stop") + (toCode.isEmpty() ? "" : " · #" + toCode);
                    if (to.length() > 1) toText += "  +1 stop";
                }
            } catch (Exception ignored) {}
        }

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.stoptap_widget);
        views.setTextViewText(R.id.route_name, routeName);
        views.setTextViewText(R.id.from_stop, fromText);
        views.setTextViewText(R.id.to_stop, toText);
        String stamp = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
        views.setTextViewText(R.id.widget_status, "Updated " + stamp + " · live arrivals next build");

        Intent refresh = new Intent(context, StopTapWidget.class);
        refresh.setAction(ACTION_REFRESH);
        refresh.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent refreshPi = PendingIntent.getBroadcast(context, widgetId, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.refresh_button, refreshPi);

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(context, widgetId + 10000, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.open_button, openPi);

        if (fromCode != null && !fromCode.isEmpty()) {
            Intent live = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.adelaidemetro.com.au/stops?id=" + fromCode));
            PendingIntent livePi = PendingIntent.getActivity(context, widgetId + 20000, live,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.from_stop, livePi);
        }
        if (toCode != null && !toCode.isEmpty()) {
            Intent live = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.adelaidemetro.com.au/stops?id=" + toCode));
            PendingIntent livePi = PendingIntent.getActivity(context, widgetId + 30000, live,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.to_stop, livePi);
        }

        manager.updateAppWidget(widgetId, views);
    }
}
